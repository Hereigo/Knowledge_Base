﻿namespace GIT_IGNORE
{
    public static class PASSWORDS
    {
        public static readonly long adminUid = 0;
        public static readonly string ftpPath = "";
        public static readonly string ftpPathDb = "";
        public static readonly string ftpUser = "";
        public static readonly string owmApiKey = "";
        public static readonly string token = "";
        public static readonly string zipOutput = "";
        public static readonly string zipOutputDB = "";
    }
}
