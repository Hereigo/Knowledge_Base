﻿namespace GIT_IGNORE
{
    public static class PASSWORDS
    {
        public const long adminUid = 0;
        public const string ftpPath = "";
        public const string ftpPathDb = "";
        public const string ftpUser = "";
        public const string mbApiPath = "";
        public const string mbUri = "";
        public const string mbXToken = "";
        public const string owmApiKey = "";
        public const string tempPathToStore = "";
        public const string token = "";
        public const string zipOutput = "";
        public const string zipOutputDB = "";
    }
}
